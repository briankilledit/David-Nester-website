You can find all the files uploaded through your application in "fileList.txt".
To download all these files, you can use the following command on Mac / Linux operating systems, you can use something like the following:

    xargs -n 1 curl -O < fileList.txt

This will download all the files to the current directory (so you may want to create and run it from a directory that you want all your files in.)

This is just one example of how to download all these files and there are many other examples on the internet.
